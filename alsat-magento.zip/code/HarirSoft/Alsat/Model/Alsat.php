<?php

namespace HarirSoft\Alsat\Model;

use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Payment\Model\InfoInterface;

class Alsat extends AbstractMethod
{
    protected $_code = 'alsat';

    public function acceptPayment(InfoInterface $payment)
    {
       return true;
    }

    public function canVoid()
    {
       return true;
    }
}
