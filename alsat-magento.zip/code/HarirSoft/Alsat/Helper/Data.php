<?php

namespace HarirSoft\Alsat\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    const BASE = 'payment/alsat/';

    /**
     * @param Context $context
     */
    public function __construct(Context $context)
    {
        parent::__construct($context);
    }

    /**
     * @return boolean
     */
    public function getMerchantId()
    {
        return $this->getConfigValue('merchant_id', static::BASE);
    }

    public function getIpgType()
    {
        return $this->getConfigValue('ipg_type', static::BASE);
    }

    private function getConfigValue($code, $path, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $path . $code, ScopeInterface::SCOPE_STORE, $storeId
        );
    }
}
