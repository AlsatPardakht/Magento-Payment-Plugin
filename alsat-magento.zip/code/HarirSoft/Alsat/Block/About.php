<?php

namespace HarirSoft\Alsat\Block;

use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Config\Block\System\Config\Form\Field;

class About extends Field
{
    protected function _getElementHtml(AbstractElement $element)
    {
        $url = 'https://harirsoft.com';

        return "<a href='{$url}'>ساخته شده توسط گروه نرم افزاری حریر سافت</a>";
    }
}
