<?php

namespace HarirSoft\Alsat\Block;

use Magento\Customer\Model\Session;
use Magento\Framework\View\Element\Template;
use Magento\Sales\Model\Order;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Sales\Model\OrderFactory;
use HarirSoft\Alsat\Helper\Alsat;
use HarirSoft\Alsat\Helper\Data;
use Magento\Sales\Model\Order\Payment\Transaction;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface;

class Redirect extends Template
{
    protected $checkoutSession;
    protected $orderFactory;
    protected $scopeConfig;
    protected $urlBuilder;
    protected $messageManager;
    protected $catalogSession;
    protected $customerSession;

    /**
     * @var $order Order
     */
    protected $order;

    /** @var Order cache */
    protected $_order;

    /** @var Alsat */
    protected $alsat;

    /** @var BuilderInterface */
    protected $transactionBuilder;

    /** @var Data */
    protected $helperData;

    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        OrderFactory $orderFactory,
        ManagerInterface $messageManager,
        Session $customerSession,
        Template\Context $context,
        BuilderInterface $transactionBuilder,
        Alsat $alsat,
        Data $helperData,
        array $data
    ) {
        parent::__construct($context, $data);

        $this->customerSession = $customerSession;
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
        $this->scopeConfig = $context->getScopeConfig();
        $this->urlBuilder = $context->getUrlBuilder();
        $this->messageManager = $messageManager;
        $this->alsat = $alsat;
        $this->helperData = $helperData;
        $this->transactionBuilder = $transactionBuilder;
    }


    /**
     * @return Order
     */
    public function getOrder()
    {
        if (!empty($this->_order)) {
            return $this->_order;
        }

        $id = $this->getRequest()->getParam('order_id', 0);

        if (empty($id)) {
            $id = $this->customerSession->getOrderId();
        }

        $this->_order = $this->orderFactory->create()->load($id);

        return $this->_order;
    }

    protected function checkOrder()
    {
        $order = $this->getOrder();

        if (empty($order) || $order->isEmpty()) {
            $this->checkoutFail('سفارش مورد نظر پیدا نشد');
        }

        if ($order->getState() != 'new') {
            $this->checkoutFail('این سفارش بسته شده است');
        }

        return $order;
    }

    public function send()
    {
        $order = $this->checkOrder();

        $this->customerSession->setOrderId($order->getId());

        $amount = $this->getOrderPrice();
        $redirect_url = $this->getUrl('alsat/Index/callback');

        $IPG_TYPE_DIRECT = $this->helperData->getIpgType();
        $OrderId = $order->getId();

        $api_key = $this->helperData->getMerchantId();
		if($IPG_TYPE_DIRECT == '0')
		{
			$Tashim = [];
			$Tsh = json_encode($Tashim);
			$data = "Amount=$amount&&ApiKey=$api_key&&Tashim=$Tsh&&RedirectAddressPage=$redirect_url";
			$response = $this->alsat->postToAlsat('send', $data);
		}
		else
		{
			$data['RedirectAddress'] = $redirect_url;
			$data['InvoiceNumber']   =  $OrderId;
			$data['Amount']   	  = $amount;
			$data['Api']   =  $api_key;
			$response = $this->alsat->postToAlsat('sign', $data);
		}
        $response = (array) $response;
        if (!isset($response['IsSuccess'], $response['Sign'])) {
            $this->checkoutFail(
                $this->alsat->resultCodes($response['result']),
                true
            );
        }

        $Token = $response['Token'];

        $startGateWayUrl = "https://www.alsatpardakht.com/IPGAPI/Api2/Go.php?Token=" . $Token ;
        
        $this->createTransaction(Transaction::TYPE_CAPTURE, [
            'id' => $Token,
            'message' => 'انتقال به درگاه پرداخت',
        ]);

        header('location: ' . $startGateWayUrl);

        exit();
    }

    public function back()
    {
        $order = $this->checkOrder();

        $tref = $this->getRequest()->getParam('tref');
        $iN = $this->getRequest()->getParam('iN');
        $iD = $this->getRequest()->getParam('iD');

        if (!$tref || is_null($tref))
            $this->checkoutFail('پرداخت موفقیت آمیز نبود.', true);
            
        $data = array(
            'tref'  => $tref,
            'iN'  => $iN,
            'iD'  => $iD,
        );
        
        $IPG_TYPE_DIRECT = $this->helperData->getIpgType();
        $OrderId = $order->getId();
        $api_key = $this->helperData->getMerchantId();
		if($IPG_TYPE_DIRECT == '1')
        {
            $data['Api'] = $api_key;
            $response = $this->alsat->postToAlsat('callback',$data);
        }
        else
        {
            $data['ApiKey'] = $api_key;
            $response = $this->alsat->postToAlsat('VerifyTransaction',$data);
        }

        // var_dump($response);
        // die();
        if (isset($response->PSP) && !$response->PSP->IsSuccess) {
            $this->checkoutFail('پرداخت انجام نشد.');
        }

        if ($this->getOrderPrice() != $response->PSP->Amount) {
            $this->checkoutFail('مبلغ پرداختی با مبلغ سبد خرید شما هم خوانی ندارد.');
        }

        $this->createTransaction(Transaction::TYPE_PAYMENT, [
            'id' => $tref,
            'message' => $message = 'پرداخت با موفقیت انجام شد',
        ]);

        $this->customerSession->setOrderId('');

        header('Location: ' . $this->getCheckoutSuccess());

        exit();
    }

    protected function createTransaction($status, $paymentData = [])
    {
        $order = $this->getOrder();

        $payment = $order->getPayment();

        $payment->setLastTransId($paymentData['id']);
        $payment->setTransactionId($paymentData['id']);

        $payment->setAdditionalInformation(
            [Transaction::RAW_DETAILS => (array)$paymentData]
        );

        $formatedPrice = $order->getBaseCurrency()->formatTxt(
            $this->getOrderPrice()
        );

        $message = __('The authorized amount is %1.', $formatedPrice);

        $transaction = $this->transactionBuilder->setPayment($payment)
            ->setOrder($order)
            ->setTransactionId($paymentData['id'])
            ->setAdditionalInformation(
                [Transaction::RAW_DETAILS => (array)$paymentData]
            )
            ->setFailSafe(true)
            ->build($status);

        $payment->addTransactionCommentsToOrder(
            $transaction,
            $message
        );

        if ($status == Transaction::TYPE_PAYMENT) {
            $payment->setIsTransactionClosed(1);
            $payment->accept();
        }

        $payment->setParentTransactionId(null);
        $payment->save();
        $order->save();

        return $transaction->save()->getTransactionId();
    }

    protected function checkoutFail($message, $closeOrder = false)
    {
        $this->checkoutSession->setErrorMessage($message);

        if ($closeOrder) {
            $order = $this->getOrder();
            $order->cancel();
            $order->addCommentToStatusHistory($message);
            $order->save();
        }

        header('Location: ' . $this->urlBuilder->getUrl('checkout/onepage/failure'));

        exit();
    }

    protected function getOrderPrice()
    {
        /** @var Order $order */
        $order = $this->getOrder();

        $amount = $order->getGrandTotal();

        if ($this->useToman()) {
            $amount = $amount / 10;
        }

        return (int)$amount;
    }

    protected function getCheckoutSuccess()
    {
        return $this->urlBuilder->getUrl('checkout/onepage/success');
    }

    private function getConfig($value)
    {
        return $this->scopeConfig->getValue('payment/alsat/' . $value, ScopeInterface::SCOPE_STORE);
    }

    protected function useToman()
    {
        return (bool)$this->getConfig('isirt');
    }
}

